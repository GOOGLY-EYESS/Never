# v10.0.0

- Nebula V10! Major release:
  - Static build target (`STATIC_BUILD=1`) — deployable to any static host, with an SVG bootloader, vocabulary scrub, and font obfuscation
  - Marketplace/catalog can be served through the proxy from a remote origin (`marketplace.origin`)
  - Custom Scramjet rewrite prefix + Base32 URL codec
  - Deterministic font obfuscation (cache-stable across builds)
  - Credits refresh: Night Network + amplify.dev

# v9.0.0

- The first release of Nebula V9! And with it bring a whole host of changes:
  - More stable the V8
  - Adds a Marketplace where users can create their own themes & plugins
  - Switches to Astro for speed
  - Other general bug fixes

# v9.0.1

- Bumps dependencies
- Fixes bugs

# 9.0.2

- Adds the ability for a custom wisp server back
- Increases upload fileSize capacity in hopes that bigger files can now be uploaded

# 9.0.3

- Bugfix: themes with caps don't uninstall - fixed
- Rewrite: InstalledThemes and InstalledPlugins are now in Astro instead of Svelte

# 9.0.4

- General Bugfixes
- Removes Svelte except for 2 componenents
- Scramjet :rocket:

# 9.1.0

- Rewrites everything in the [utils/](./src/utils) folder
- Bugfixes
- Better logging
- Mobile nav jank is gone
- Component cleanup

# 9.1.1

- Fixes up a small issue with postgres connections and Unix sockets

# 9.1.2
- Allows unix sockets without a port

# 9.1.3
- Fixes some more bugs

# 9.1.4
- Fixes an issue with the marketplace API failing to fetch on some instances.
- Now avoids a hairpin call with the marketplace API
